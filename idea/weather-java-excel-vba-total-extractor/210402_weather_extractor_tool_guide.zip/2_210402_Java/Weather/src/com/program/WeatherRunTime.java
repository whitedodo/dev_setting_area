/*
 * 	생성일자: 2021-04-02
 * 	파일명: WeatherRunTime.java
 * 	작성자: Dodo(도도)
 *  라이센스: Apache License v2.0
 *  비고:
 *  1. Runnable(쓰레드) 구현, 도도(Dodo), 2021-04-02
 *  
 * 
 * 
 */
package com.program;

import java.io.IOException;
import java.text.ParseException;

import com.program.config.ConfigNode;
import com.program.config.ConfigWeather;
import com.program.model.Weather;
import com.program.util.UtilFileIO;

public class WeatherRunTime implements Runnable {

    private String charset;
    private ConfigWeather config;
    
    public WeatherRunTime() {
    	
    	this.setCharset( "UTF-8" );	// 기본값: UTF-8
    	config = null;
    	
    }
    
    public WeatherRunTime(String charset, ConfigWeather configNode) {
    	
    	this.setCharset( charset );
    	this.config = configNode;
    }
    

	@Override
	public void run() {
		
		System.out.println("Weather RunTime - START " + Thread.currentThread().getName() );
		action();
				
	}

	private void action() {

		String charset = getCharset();
		// String fileReadName = config.getFileReadName();
		// String fileSaveName = config.getFileSaveName();
		
		int year = 2019;
		
		UtilFileIO fileIO = new UtilFileIO();
		Weather[] arrWeather = null;
		
		fileIO.setCharset(charset);
		
		//String fileReadName = 
		//String fileSaveName = 
		
		try {
			// csvExtractor.customCSVReaderWeather("210402_weather_local.csv");
			// fileIO.customCSVReaderWeather(fileName);
			//fileIO.commonCSVReader(fileName);
			arrWeather = fileIO.commonCSVReaderWeather( year, config );
			fileIO.printWeather( arrWeather, arrWeather.length );
			fileIO.commonWriterCSVWeather( config, arrWeather, arrWeather.length );
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
	}
	
    public String getCharset() {
    		return charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}
	
}
