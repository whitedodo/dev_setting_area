/*
 * 	생성일자: 2021-04-02
 * 	파일명: UtilDate.java
 * 	작성자: Dodo(도도)
 *  라이센스: Apache License v2.0
 *  비고:
 *  1. 문자열 to 날짜 변환, 도도(Dodo), 2021-04-02.
 *  2. 날짜 to 문자열 변환, 도도(Dodo), 2021-04-02.
 * 
 * 
 */
package com.program.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.program.model.Weather;

public class UtilDate {
		
	public static Date strToDate(String from) {  
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		// String from = "2013-04-08";
		// String from = null; 
		Date to = null;
		
		try {
			to = transFormat.parse(from);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return to;
		
	}
	
	public static Date strToDate(String from, String customFormat) {  
		
		SimpleDateFormat transFormat = new SimpleDateFormat(customFormat);
		
		// String from = "2013-04-08";
		// String from = null; 
		Date to = null;
		
		try {
			to = transFormat.parse(from);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return to;
		
	}
	
	public static String dateToStr(String from) {
		
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String to = transFormat.format(from);
		
		return to;
	}

	public static String dateToStr(String from, String customFormat) {
		
		SimpleDateFormat transFormat = new SimpleDateFormat(customFormat);
		String to = transFormat.format(from);
		
		return to;
	}
	
	public static String getDateNumber(int number) {
		
		String value = "";
		
		if ( number >= 10 ) {
			value = Integer.toString(number);
		}else {
			value = "0" + Integer.toString(number);
		}
		
		return value;
		
	}
	
	public static double getMonthToTemperature( int month, Weather weatherNode ) {
		
		double result = 0.0;
		
		switch ( month ) {
		
		case 1:
			result = weatherNode.getJan();			
			break;
			
		case 2:
			result = weatherNode.getFeb();
			break;
			
		case 3:
			result = weatherNode.getMarch();
			break;
			
		case 4:
			result = weatherNode.getApril();
			break;
			
		case 5:
			result = weatherNode.getMay();
			break;
			
		case 6:
			result = weatherNode.getJune();
			break;
			
		case 7:
			result = weatherNode.getJuly();
			break;
			
		case 8:
			result = weatherNode.getAugust();
			break;
			
		case 9:
			result = weatherNode.getSep();
			break;
			
		case 10:
			result = weatherNode.getOct();
			break;
			
		case 11:
			result = weatherNode.getNov();
			break;
			
		case 12:
			result = weatherNode.getDec();
			break;
		}
		
		return result;
		
	}
	
}
