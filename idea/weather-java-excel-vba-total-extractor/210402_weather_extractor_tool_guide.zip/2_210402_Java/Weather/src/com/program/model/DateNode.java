/*
 * 	생성일자: 2021-04-02
 * 	파일명: DateNode.java
 * 	작성자: Dodo(도도)
 *  라이센스: Apache License v2.0
 *  비고:
 * 	1. 데이터 노드, 도도(Dodo), 2021-04-02
 *  2. 날짜 노드 구현함, 도도(Dodo), 2021-04-02
 * 
 * 
 */
package com.program.model;

public class DateNode {

	private int year;
	private int month;
	private int day;
	
	private int hour;
	private int min;
	private int sec;
	
	private String eggValue;	// 개발자1 애그 영역
	private String result;		// 결과값 반환 영역
	private String eggValue1;	// 개발자2 애그 영역
	private String eggValue2;	// 개발자3 애그 영역
		
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public int getHour() {
		return hour;
	}
	public void setHour(int hour) {
		this.hour = hour;
	}
	public int getMin() {
		return min;
	}
	public void setMin(int min) {
		this.min = min;
	}
	public int getSec() {
		return sec;
	}
	public void setSec(int sec) {
		this.sec = sec;
	}
	
	public String getEggValue() {
		return eggValue;
	}
	public void setEggValue(String eggValue) {
		this.eggValue = eggValue;
	}
	
	public String getEggValue1() {
		return eggValue1;
	}
	public void setEggValue1(String eggValue1) {
		this.eggValue1 = eggValue1;
	}
	
	public String getEggValue2() {
		return eggValue2;
	}
	public void setEggValue2(String eggValue2) {
		this.eggValue2 = eggValue2;
	}
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
}
