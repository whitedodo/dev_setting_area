/*
 * 	생성일자: 2021-04-02
 * 	파일명: ConfigNode.java
 * 	작성자: Dodo(도도)
 *  라이센스: Apache License v2.0
 *  비고:
 * 
 * 
 * 
 */
package com.program.config;

public class ConfigNode {

	private String charset;
	
	private String realPath;
	private String filePath;	
	private String fileReadName;
	private String fileSaveName;
	
	public String getCharset() {
		return charset;
	}
	public void setCharset(String charset) {
		this.charset = charset;
	}
	
	public String getRealPath() {
		return realPath;
	}
	public void setRealPath(String realPath) {
		this.realPath = realPath;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getFileReadName() {
		return fileReadName;
	}
	public void setFileReadName(String fileReadName) {
		this.fileReadName = fileReadName;
	}
	public String getFileSaveName() {
		return fileSaveName;
	}
	public void setFileSaveName(String fileSaveName) {
		this.fileSaveName = fileSaveName;
	}
	
	
}
