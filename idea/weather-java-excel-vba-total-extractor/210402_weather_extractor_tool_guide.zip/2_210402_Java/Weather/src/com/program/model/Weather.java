/*
 * 	생성일자: 2021-04-02
 * 	파일명: Weather.java
 * 	작성자: Dodo(도도)
 *  라이센스: Apache License v2.0
 *  비고:
 * 
 * 
 * 
 */
package com.program.model;

public class Weather {

	private int flag;		// 플래그(깃발)
	private int year;		// 년
	private int day; 		// 일
	private int areacode;	// 지역(식별키)
	private String areaname;	// 지역명
	
	private double jan;	// 1월
	private double feb;	// 2월
	private double march;	// 3월	
	private double april;	// 4월
	private double may;	// 5월
	private double june; 	// 6월
	private double july;	// 7월
	private double august;	// 8월
	private double sep;	// 9월
	private double oct;	// 10월
	private double nov;	// 11월
	private double dec;	// 12월
	
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	
	public int getYear() {
		return year;
	}
	
	public void setYear(int year) {
		this.year = year;
	}
	
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	
	public int getAreacode() {
		return areacode;
	}
	public void setAreacode(int areacode) {
		this.areacode = areacode;
	}
	public String getAreaname() {
		return areaname;
	}
	public void setAreaname(String areaname) {
		this.areaname = areaname;
	}
	
	public double getJan() {
		return jan;
	}
	public void setJan(double jan) {
		this.jan = jan;
	}
	public double getFeb() {
		return feb;
	}
	public void setFeb(double feb) {
		this.feb = feb;
	}
	public double getMarch() {
		return march;
	}
	public void setMarch(double march) {
		this.march = march;
	}
	public double getApril() {
		return april;
	}
	public void setApril(double april) {
		this.april = april;
	}
	public double getMay() {
		return may;
	}
	public void setMay(double may) {
		this.may = may;
	}
	public double getJune() {
		return june;
	}
	public void setJune(double june) {
		this.june = june;
	}
	public double getJuly() {
		return july;
	}
	public void setJuly(double july) {
		this.july = july;
	}
	public double getAugust() {
		return august;
	}
	public void setAugust(double august) {
		this.august = august;
	}
	public double getSep() {
		return sep;
	}
	public void setSep(double sep) {
		this.sep = sep;
	}
	public double getOct() {
		return oct;
	}
	public void setOct(double oct) {
		this.oct = oct;
	}
	public double getNov() {
		return nov;
	}
	public void setNov(double nov) {
		this.nov = nov;
	}
	public double getDec() {
		return dec;
	}
	public void setDec(double dec) {
		this.dec = dec;
	}
	
	
	
}
