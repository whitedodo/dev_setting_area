/*
 * 	생성일자: 2021-04-02
 * 	파일명: CommonValidator.java
 * 	작성자: Dodo(도도)
 *  라이센스: Apache License v2.0
 *  비고:
 *  1. 유효성 검사 도구, 도도(Dodo), 2021-04-02
 *  
 * 
 * 
 */
package com.program.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class CommonValidator {

	public boolean validationDate(String checkDate){

		try{
	    
			SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyy-MM-dd" );

			dateFormat.setLenient( false );
			dateFormat.parse( checkDate );

			return true;
	     
		}catch ( ParseException e ){

			return false;
		}
	 
	 }
	
	 
}
