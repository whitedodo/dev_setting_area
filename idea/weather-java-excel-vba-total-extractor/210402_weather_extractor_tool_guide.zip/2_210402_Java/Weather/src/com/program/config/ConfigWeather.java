/*
 * 	생성일자: 2021-04-02
 * 	파일명: ConfigWeather.java
 * 	작성자: Dodo(도도)
 *  라이센스: Apache License v2.0
 *  비고:
 *  1. 객체 확장(부모) - ConfigNode를 부모로 함, 도도(Dodo), 2021-04-02
 * 
 */
package com.program.config;

public class ConfigWeather extends ConfigNode {

	private int areacode;
	private String areaname;
	
	public int getAreacode() {
		return areacode;
	}
	public void setAreacode(int areacode) {
		this.areacode = areacode;
	}
	public String getAreaname() {
		return areaname;
	}
	public void setAreaname(String areaname) {
		this.areaname = areaname;
	}
	
}
