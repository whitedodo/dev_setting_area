/*
 * 	생성일자: 2021-04-02
 *  주제명: 날씨 추출 / 행과 열 변환 프로그램(CSV)
 * 	파일명: WeatherMain.java
 * 	작성자: Dodo(도도)
 *  라이센스: Apache License v2.0
 *  비고:
 *  1. 처음 작성, 도도(Dodo), 2021-04-02.
 *  2. 운영체제 이론 적용됨. (Thread / 쓰레드), 도도(Dodo), 2021-04-02.
 * 
 * 
 */

package com.program;

import com.program.config.ConfigWeather;

public class WeatherMain {

	public static void main(String[] args) {
		
		ConfigWeather configNode = new ConfigWeather();
		
		// 윈도우 방식(MS윈도우)
		String usrPath = "c:\\weather\\";
		String usrReadName = "210402_weather_local.csv";
		String usrSaveName = "210402_weather_save.csv";
		
		// 리눅스 방식
		//usrPath = "/tmp/";
		// usrReadName = "210402_weather_.csv";
		// usrSaveName = "210402_weather_save.csv";
		// usrCustomFilePath = "sample.csv";
		
		configNode.setAreacode(1);
		configNode.setAreaname("도도시");
		
		configNode.setFilePath( usrPath );
		configNode.setFileReadName( usrReadName );
		configNode.setFileSaveName( usrSaveName );
		
		Thread tMain = new Thread( new WeatherRunTime("UTF-8", configNode), "t1" );
		tMain.start();
		
		try { 
			Thread.sleep(1000); 
		} catch (InterruptedException e) {
			
		}
		
		tMain.interrupt(); // 스레드를 종료시키기 위해 InterruptedException을 발생시킴
		
	}
		
}
