/*
 * 	생성일자: 2021-04-02
 * 	파일명: CustomWeatherParser.java
 * 	작성자: Dodo(도도)
 *  라이센스: Apache License v2.0
 *  비고:
 * 
 * 
 * 
 */
package com.program.util;

import com.program.model.DateNode;
import com.program.model.Weather;

public class CustomWeatherParser {

	private int typeMode;	// 유형
	private int mode;		// 출력: 1, 출력안함: 0
	
	private final int TRUE_WEATHER_MODE = 1;
	private final int MIXED_WEATHER_MODE = 2;
	
	// 서비스 접근 레벨
	private final int TYPEMODE_GETCOMA = 1;
	private final int TYPEMODE_GETWEATHER = 2;

	private final int MODE_PRINT_OFF = 0;
	private final int MODE_PRINT_ON = 1;

	// 플래그 옵션
	public void setFlag(int typeMode, int mode) {
		
		this.typeMode = typeMode;
		this.mode = mode;
		
	}
	
	// 개발자 모드
	public int getTYPEMODE_GETCOMA() {
		return TYPEMODE_GETCOMA;
	}

	public int getTYPEMODE_GETWEATHER() {
		return TYPEMODE_GETWEATHER;
	}

	public int getMODE_PRINT_OFF() {
		return MODE_PRINT_OFF;
	}

	public int getMODE_PRINT_ON() {
		return MODE_PRINT_ON;
	}

	// 콤마 분리
	public String getComa(String value) {

		int colNum = 0;
		
		//String frameTxt = getFrameTxt(value);

		//String frameTxt = value;
		String replaceTxt = value;
		
		int tmpStart = 0;
		int tmpEnd = 1;
		String tmpValue = "";
		
		String result = "";
		
		while ( replaceTxt.indexOf(",") > -1 ) {
			
			
			tmpStart = 0;
			tmpEnd = replaceTxt.indexOf(",");
			tmpValue = replaceTxt.substring(tmpStart, tmpEnd);
			
			result = tmpValue;
			
			replaceTxt = replaceTxt.replace(tmpValue + ",", "");
			
			if ( colNum > 0) {
				System.out.println(result + "/" + colNum);
			}
			
			colNum++;
			
		}
		
		// 마지막 열
		if ( colNum != 0 ) {
			// result
		}
		
		return result;
		
	}
	
	// 날씨 추출
	public Weather[] getWeatherComa(Weather[] arrWeather, DateNode dateNode) {

		int colNum = 0;
		int day = dateNode.getDay();
		
		String value = dateNode.getEggValue();
		String replaceTxt = value;
		Weather weatherNode = new Weather();  
		weatherNode.setDay( day );
		
		int tmpStart = 0;
		int tmpEnd = 1;
		String tmpValue = "";
		
		String result = "";
		
		while ( replaceTxt.indexOf(")") > -1 ) {
			
			tmpStart = 0;
			tmpEnd = replaceTxt.indexOf(")");
			
			tmpValue = replaceTxt.substring(tmpStart, tmpEnd);
						
			result = tmpValue;
			replaceTxt = replaceTxt.replace(tmpValue + ")", "");
			
			// 1월 ~ 11월
			if ( colNum > 0) {
				dateNode.setMonth(colNum);
				dateNode.setResult(result);
				weatherNode = createWeather(dateNode, weatherNode);
			}
			
			// 1~11월 (출력)
			if ( colNum > 0 
					&& 
				(this.typeMode * this.mode != 0) ) {
					System.out.println(result + "/" + colNum );
			}
			
			colNum++;
			
		}
		
		// 결과값 찾기
		if (replaceTxt == "") {			
			result = replaceTxt;
		}
		
		// 마지막 열
		if ( colNum != 0 ) {
			// result
			dateNode.setMonth(colNum);
			dateNode.setResult(result);
			weatherNode = createWeather(dateNode, weatherNode);
		}

		// 마지막 열(서비스 모드)
		if ( ( colNum != 0 )
				&& 
			(this.typeMode * this.mode != 0) ) {
				System.out.println(replaceTxt + "/" + colNum );
				System.out.println();
		}
		
		//arrWeather[ day - 1 ] = weatherNode;
		
		return arrWeather;
		
	}
	
	public Weather createWeather(DateNode value, Weather weather) {
		
		int column = value.getMonth();
		// String tmpResult = value.getResult();
		Double doubleResult = 0.0;
				
		String strValue = value.getResult();
		
		// 플래그(깃발)
		if ( strValue == "" ) {
			weather.setFlag(MIXED_WEATHER_MODE);
		}
		else {
			weather.setFlag(TRUE_WEATHER_MODE);
		}
			
		// 월별 데이터 값 설정 
		switch (column){
			
			case 1:
				weather.setJan( doubleResult );
				break;
				
			case 2:
				weather.setFeb( doubleResult );
				break;
				
			case 3:
				weather.setMarch( doubleResult );
				break;
				
			case 4:
				weather.setApril( doubleResult );
				break;
				
			case 5:
				weather.setMay( doubleResult );
				break;
				
			case 6:
				weather.setJune( doubleResult );
				break;
				
			case 7:
				weather.setJuly( doubleResult );
				break;
				
			case 8:
				weather.setAugust( doubleResult );
				break;
				
			case 9:
				weather.setSep( doubleResult );
				break;
				
			case 10:
				weather.setOct( doubleResult );
				break;
				
			case 11:
				weather.setNov( doubleResult );
				break;
				
			case 12:
				weather.setDec( doubleResult );
				break;
			
			
		} // end of switch
		
		
		return weather;
	}
	
	public String getFrameTxt(String value) {

		int tmpStart = 1;
		int tmpEnd = 1;
		String tmpValue = "";
		String replaceValue = "";
		
		tmpStart = 0;
		tmpEnd = value.indexOf(",");
		tmpValue = value.substring(tmpStart, tmpEnd);
		replaceValue = value.replace(tmpValue + ",", "");
		
		return replaceValue;
		
	}
	
}
