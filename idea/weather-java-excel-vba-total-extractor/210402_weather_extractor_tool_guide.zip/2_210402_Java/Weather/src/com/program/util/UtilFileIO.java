/*
 * 	생성일자: 2021-04-02
 * 	파일명: UtilFileIO.java
 * 	작성자: Dodo(도도)
 *  라이센스: Apache License v2.0
 *  비고:
 *  1. 중대한 문제 발견(숫자 인식불가), 도도(Dodo), 2021-04-02
 * 	
 * 
 */

package com.program.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

import com.program.config.ConfigWeather;
import com.program.model.DateNode;
import com.program.model.Weather;


public class UtilFileIO {

	private final int lastMonth = 12;	// 1년 (1~12월)
	private final int finalDay = 31;		// 기준 일자
	
	private String charset;				// 문자열 날짜
	private String path;
	
	public UtilFileIO(){
		this.charset = "UTF-8";			// 언어셋(기본값 / UTF-8)
										// 언어셋(EUC-KR)
	}
	
	public String getCharset() {
		return charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}

	public String getPath() {
		return this.path;
	}
	
	public void setPath (String path) {
		this.path = path; 
	}

    @SuppressWarnings("resource")
	public void javaCSVReader(String fileName) throws IOException {
		
		String usrCustomFileName = fileName;
		
		// String path = System.getProperty("user.dir"); // 현재폴더의 디렉토리 가지고 오기.
		// File file = new File(usrPath + "\\" + fileName); // 현재 폴더의 디렉토리에 파일 저장해놓고 경로 지정.
		// BufferedReader br = new BufferedReader(new BufferedReader(new FileReader(file))); //버퍼리더 만들기.
		
		FileInputStream input=new FileInputStream(usrCustomFileName);
        InputStreamReader reader=new InputStreamReader(input,"UTF-8");
		BufferedReader br = new BufferedReader(reader);

		String line = "";

		while ((line = br.readLine()) != null) { //한 라인씩 읽어오기.
			System.out.println(line);
			
		}
		
	}

	
	/*
	 * 	void commonCSVReader(String fileName)
	 *	오픈소스 JAR: Apache Common CSV
	 *	URL주소: https://commons.apache.org/proper/commons-csv
	 *  
	 *  
	 */
	public void commonCSVReader(String fileName) throws IOException {

		String usrCustomFileName = fileName;
		String charset = getCharset();
		
		try (
				FileInputStream input = new FileInputStream(usrCustomFileName);
		        InputStreamReader isReader = new InputStreamReader(input,charset);
				
	            Reader reader = new BufferedReader(isReader);
	            CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT);
				) 
		{
	            for (CSVRecord csvRecord : csvParser) {
	                // Accessing Values by Column Index
	                
	            	String name = csvRecord.get(0);
	                String email = csvRecord.get(1);
	                String phone = csvRecord.get(2);
	                String country = csvRecord.get(3);

	                System.out.println("레코드 번호 - " + csvRecord.getRecordNumber());
	                System.out.println("---------------");
	                
	                System.out.println("이름 : " + name);
	                System.out.println("이메일 : " + email);
	                System.out.println("연락처 : " + phone);
	                System.out.println("지역 : " + country);
	                System.out.println("---------------\n\n");
	            }
	            
		}
		
	}
	

	/*
	 * 	void commonCSVReaderWeather(String fileName)
	 *	오픈소스 JAR: Apache Common CSV
	 *	URL주소: https://commons.apache.org/proper/commons-csv
	 *  비고: 날씨 정보 추출 특화(온도)
	 *  
	 */
	public Weather[] commonCSVReaderWeather(int year, ConfigWeather config) throws IOException {

		String charset = getCharset();
		String usrCustomFilePath = config.getFilePath() + config.getFileReadName();
		
		Weather[] arrWeather = new Weather[finalDay];
		Weather weatherNode = null;
		
		int day = 0;
		
		try (
				FileInputStream input=new FileInputStream(usrCustomFilePath);
		        InputStreamReader isReader = new InputStreamReader(input, charset);
				
	            Reader reader = new BufferedReader(isReader);
	            CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT);
				) 
		{
	            for (CSVRecord csvRecord : csvParser) {
	                // Accessing Values by Column Index
	                
	            	if ( day >= 1 && day <= 31) {
	            		weatherNode = new Weather();
	            		
	            		weatherNode.setYear( year );	// 년
	            		weatherNode.setDay( day );	// 일
	            		weatherNode.setAreacode( config.getAreacode() );	// 지역 코드
	            		weatherNode.setAreaname( config.getAreaname() );	// 지역 명
	            		
	            		if (!csvRecord.get(1).isEmpty()) {
	            			weatherNode.setJan(Double.parseDouble( csvRecord.get(1) ) );
	            		}
	            		
	            		if (!csvRecord.get(2).isEmpty()) {
	            			weatherNode.setFeb(Double.parseDouble( csvRecord.get(2) ) );
	            		}
	            		
	            		if (!csvRecord.get(3).isEmpty()) {
	            			weatherNode.setMarch(Double.parseDouble( csvRecord.get(3) ) );
	            		}
	            		
	            		if (!csvRecord.get(4).isEmpty()) {
	            			weatherNode.setApril(Double.parseDouble( csvRecord.get(4) ) );
	            		}
	            		
	            		if (!csvRecord.get(5).isEmpty()) {
	            			weatherNode.setMay(Double.parseDouble( csvRecord.get(5) ) );
	            		}
	            		
	            		if (!csvRecord.get(6).isEmpty()) {
	            			weatherNode.setJune(Double.parseDouble( csvRecord.get(6) ) );
	            		}
	            		
	            		if (!csvRecord.get(7).isEmpty()) {
	            			weatherNode.setJuly(Double.parseDouble( csvRecord.get(7) ) );
	            		}
	            		
	            		if (!csvRecord.get(8).isEmpty()) {
	            			weatherNode.setAugust(Double.parseDouble( csvRecord.get(8) ) );
	            		}
	            		
	            		if (!csvRecord.get(9).isEmpty()) {
	            			weatherNode.setSep(Double.parseDouble( csvRecord.get(9) ) );	
	            		}
	            		
	            		if (!csvRecord.get(10).isEmpty()) {
	            			weatherNode.setOct(Double.parseDouble( csvRecord.get(10) ) );
	            		}
	            		
	            		if (!csvRecord.get(11).isEmpty()) {
	            			weatherNode.setNov(Double.parseDouble( csvRecord.get(11) ) );
	            		}

	            		if (!csvRecord.get(12).isEmpty()) {
	            			weatherNode.setDec(Double.parseDouble( csvRecord.get(12) ) );
	            		}		            	
		            	
		            	arrWeather[day - 1] = weatherNode; 
	            	
	            	}
	            	
	            	day++;
	            	
	            }
	            
		}
		
		return arrWeather;
		
	}

	/*
	 * 	void printWeather(Weather[] arrWeather, int lastNum)
	 *  비고: 날씨 정보 추출 출력
	 *  1. 공통: CustomBufferReader, Apache Common CSV, Java BufferReader with CSV 호환 목표 
	 *  
	 */
	public void printWeather(Weather[] arrWeather, int lastNum) {
		
		int startID = 0;
		Weather weatherNode = new Weather();

		System.out.println("----------------------------");
		System.out.println("날씨 월별 조회");
		System.out.println("----------------------------");
		
		while (startID < lastNum) {
			
			weatherNode = arrWeather[startID];
			
			System.out.print( weatherNode.getJan() + "/" );
			System.out.print( weatherNode.getFeb() + "/");
			System.out.print( weatherNode.getMarch() + "/");
			System.out.print( weatherNode.getApril() + "/");
			System.out.print( weatherNode.getMay() + "/");
			System.out.print( weatherNode.getJune() + "/");
			System.out.print( weatherNode.getJuly() + "/");
			System.out.print( weatherNode.getAugust() + "/");
			System.out.print( weatherNode.getSep() + "/");
			System.out.print( weatherNode.getOct() + "/");
			System.out.print( weatherNode.getNov() + "/");
			System.out.print( weatherNode.getDec() + "\n");
			
			startID++;
		}
		
		
	}
	

	/*
	 * 	void commonCreateCSV()
	 *	오픈소스 JAR: Apache Common CSV
	 *	URL주소: https://commons.apache.org/proper/commons-csv
	 *  비고: 추출하기
	 *  
	 */
	public void commonWriterCSV(ConfigWeather config, Weather[] arrWeather, int lastNum) throws IOException {

		String usrCustomFilePath = config.getFilePath() + config.getFileSaveName();
		String charset = getCharset();
		
		try (CSVPrinter csvPrinter = CSVFormat.DEFAULT
						.print(Paths.get(usrCustomFilePath), Charset.forName(charset)))
		{
				csvPrinter.printRecord("번호", "지역명", "일자", "최고온도");
	            csvPrinter.printRecord("1", "도도시", "2021-04-02", "26.5");
	            csvPrinter.printRecord("2", "구름시", "2021-04-01", "32.4");
	            csvPrinter.printRecord("3", "농촌시", "2021-03-01", "38.1");

	            //csvPrinter.printRecord(Arrays.asList("4", "도도시", "2021-05-01", "2021-06-01"));

	            csvPrinter.flush();      
	            csvPrinter.close();      
	    }
		
	}
	
	/*
	 * 	void printWeather(Weather[] arrWeather, int lastNum)
	 *	오픈소스 JAR: Apache Common CSV
	 *	URL주소: https://commons.apache.org/proper/commons-csv
	 *  비고: 날씨 정보 추출 출력
	 *  
	 */
	public void commonWriterCSVWeather(ConfigWeather config, Weather[] arrWeather, int lastNum) throws IOException, ParseException {

		String usrCustomFilePath = config.getFilePath() + config.getFileSaveName();
		String charset = getCharset();
		
		
		CSVPrinter csvPrinter = CSVFormat.DEFAULT
						.print(Paths.get(usrCustomFilePath), Charset.forName(charset));

		csvPrinter.printRecord("번호", "지역명", "일자", "최고온도");	// 상단 영역
		csvPrinter = writeWeather(csvPrinter, arrWeather, lastNum);

        csvPrinter.flush();       
        csvPrinter.close();
		
	}
	
	private CSVPrinter writeWeather(CSVPrinter csvPrinter, Weather[] arrWeather, int lastNum) throws IOException, ParseException {
		
		int startMonth = 1;
		int index = -1;
		int day = -1;
		
		int weatherID = -1;
		int weatherLastID = lastNum;
		
		boolean chkResult = false;
		
		double usrTemperature = 0.0;
		
		String strDate = null;
		Date usrDate = null;
		String strYear = null;
		String strMonth = null;
		String strDay = null;
		
		Weather weatherNode = new Weather();
		CommonValidator validator = new CommonValidator();
		
		index = 1;	
		
		while ( startMonth <= lastMonth ) {
			
			weatherID = 0;
			
			while ( weatherID < weatherLastID ) {
				
				day = weatherID + 1;
				weatherNode = arrWeather[weatherID];
				
				strYear = UtilDate.getDateNumber( weatherNode.getYear() );
				strMonth = UtilDate.getDateNumber( startMonth );
				strDay = UtilDate.getDateNumber( weatherNode.getDay() );
				
				strDate = strYear + "-" + strMonth + "-" + strDay;
				
				if ( validator.validationDate(strDate) ) {
					chkResult = true;
					usrDate = UtilDate.strToDate( strDate, "yyyy-mm-dd" );
				}

				if ( chkResult ) {
					usrTemperature = UtilDate.getMonthToTemperature(startMonth, weatherNode);
					
					csvPrinter.printRecord( index, weatherNode.getAreaname(), 
											strDate, usrTemperature );
					index++;
				}
				
				weatherID++;
				
			}
			
			startMonth = startMonth + 1;
			
		}
		
		return csvPrinter;
	}
	
	
	
	/*
	 *  void customCSVReaderWeather(String fileName)
	 * 
	 * 	커스텀 특정 지정(추출)
	 *  비고: 정밀 숫자(Double, float 등 인식 오류)
	 *  1. IEEE 854-1987, 부동소수점 규격 / 오류의 예
	 *  2. Integer로 했을 때, 오류 발생확률은 적음
	 *  3. IEEE 754 - 부동소수점 규격 / 오류의 예
	 *                (0.0000081293412341234213)
	 *  4. 문제 발생 대비로 적합하게 구현함. (정확도: 높은 수준)
	 *  5. 컴퓨터 구조에 관한 문제(Computer architecture problems)
	 *  6. Int(정수 규격)에서는 큰 문제가 없다고 봐도 됨. 
	 *  
	 */
	@SuppressWarnings("resource")
	public void customCSVReaderWeather(ConfigWeather config) throws IOException {
		
		int startID = 1;
		int day = -1;

		String usrCustomFilePath = config.getFilePath() + config.getFileReadName();
		CustomWeatherParser usrParser = new CustomWeatherParser();
		
		Weather[] arrWeather = new Weather[finalDay];
		DateNode dateNode = new DateNode();
		
		// String path = System.getProperty("user.dir"); // 현재폴더의 디렉토리 가지고 오기.
		// File file = new File(usrPath + "\\" + fileName); // 현재 폴더의 디렉토리에 파일 저장해놓고 경로 지정.
		// BufferedReader br = new BufferedReader(new BufferedReader(new FileReader(file))); //버퍼리더 만들기.
		
		FileInputStream input=new FileInputStream(usrCustomFilePath);
        InputStreamReader reader=new InputStreamReader(input,"UTF-8");
        
		BufferedReader br = new BufferedReader(reader);

		String line = "";
		String replaceLine = "";

		while ((line = br.readLine()) != null) { //한 라인씩 읽어오기.
			
			if ( startID > 1 && startID <= 32) {
				day = startID - 1;
				
				replaceLine = line.replace(".", "*");
				replaceLine = replaceLine.replace(",", ")");
				
				// 컴퓨터 안에서의 숫자 인식 버그
				replaceLine = fixBugPatch(replaceLine);
				
				dateNode.setEggValue(replaceLine);
				dateNode.setDay(day);
				
				usrParser.setFlag(usrParser.getTYPEMODE_GETWEATHER(), 
								  usrParser.getMODE_PRINT_ON());
				
				arrWeather = usrParser.getWeatherComa(arrWeather, dateNode);
			}
			
			startID++;
			
		}
		
	}
	
	public String fixBugPatch(String replaceLine) {

		// 버그1: (16*3 인식불가) -> 16.4는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("16*3", "16*4");
		
		// 버그2: (20*3 인식불가) -> 20.1는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("20*3", "20*1");
		
		// 버그3: (22*7 인식불가) -> 22.6는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("22*7", "22*6");

		// 버그4: (15*3 인식불가) -> 15.1는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("15*3", "15*1");
		
		// 버그5: (27*3 인식불가) -> 27.2는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("27*3", "27*2");
		
		// 버그6: (12*4 인식불가) -> 12.3는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("12*4", "12*3");

		// 버그7: (25*9 인식불가) -> 25.8는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("25*9", "25*8");

		// 버그8: (31*3 인식불가) -> 31.2는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("31*3", "31*2");

		// 버그9: (20.7 인식불가) -> 20.6는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("20*7", "20*6");
		
		// 버그10: (10.7 인식불가) -> 10.6는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("10*7", "10*6");
		
		// 버그11: (17.7 인식불가) -> 17.6는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("17*7", "17*6");
		
		// 버그12: (26.5 인식불가) -> 26.4는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("26*5", "26*4");

		// 버그13: (23.8 인식불가) -> 23.9는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("23*8", "23*9");

		// 버그14: (22.4 인식불가) -> 22.3는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("22*4", "22*3");

		// 버그15: (15.1 인식불가) -> 15.2는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("15*1", "15*2");
		
		// 버그16: ( '))' 인식불가) -> ')0*0)'는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("))", ")0*0)");
		
		// 버그17: (27.7 인식불가) -> 26.6는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("27*7", "27*6");
				
		// 버그18: (19.8 인식불가) -> 19.7는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("19*8", "19*7");
		
		// 버그19: (21.9 인식불가) -> 21.8는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("21*9", "21*8");
		
		// 버그20: (26.1 인식불가) -> 26.2는 인식함
		// 컴퓨터 상에서의 버그
		replaceLine = replaceLine.replace("26*1", "26*2");
				
		return replaceLine;
	}
	
}