#!/bin/sh
PASS1="hello1234**&&"
PASS2="12341234"

case $1 in
	127.0.1.1:443)
		echo $PASS1;;
	2001:1111:1111::81:443)
		echo $PASS1;;
	www.hello.com:443)
		echo $PASS2;;
esac
exit 0
